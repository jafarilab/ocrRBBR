#' Human ATAC-seq data
"human_atacseq_data"

#' Mouse ATAC-seq data
"mouse_atacseq_data"

#' Human RNA-seq data
"human_rnaseq_data"

#' Mouse RNA-seq data
"mouse_rnaseq_data"

#' Human peaks GRanges
"human_peaks_gr"

#' Mouse peaks GRanges
"mouse_peaks_gr"

#' Human cell type information
"human_cell_type"

#' Human metadata
"human_meta_data"